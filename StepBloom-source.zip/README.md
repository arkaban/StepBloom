# StepBloom

StepBloom is an original, lightweight VST3 volume shaper. Draw a 16-point
gain curve, set its depth, and choose a one-, two-, or four-bar cycle. The
pattern follows the host's tempo and playback position; when the host is
stopped or does not provide a position, it free-runs at the host tempo or
120 BPM.

## Build on Windows

Requirements:

- CMake 3.22 or newer
- Visual Studio 2022 with the C++ desktop workload
- Git and an internet connection for the first configure (JUCE 8.0.8 is fetched
  and pinned by CMake)

From a Visual Studio Developer PowerShell in this directory:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target StepBloom_VST3
```

The VST3 bundle is produced under `build/StepBloom_artefacts/Release/VST3`.
Copy the bundle into your DAW's VST3 scan folder if it is not discovered
automatically.

The audio thread uses a 16-value curve, linear interpolation, and one
smoothed gain multiplier per sample. It does not allocate memory or perform
locking in the processing loop. JUCE is included as a build dependency; consult
its license terms for your distribution plans.
