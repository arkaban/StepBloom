#include "PluginEditor.h"

namespace
{
const juce::Colour backgroundColour{0xff10151d};
const juce::Colour panelColour{0xff171f2a};
const juce::Colour gridColour{0xff2c3746};
const juce::Colour accentColour{0xff67e3b3};
const juce::Colour textColour{0xffe9f0f5};
}

StepBloomAudioProcessorEditor::CurveEditor::CurveEditor(
    StepBloomAudioProcessor::Parameters& state)
    : parameters(state)
{
    setMouseCursor(juce::MouseCursor::CrosshairCursor);
}

void StepBloomAudioProcessorEditor::CurveEditor::paint(juce::Graphics& graphics)
{
    auto bounds = getLocalBounds().toFloat();
    plotArea = bounds.reduced(18.0f, 16.0f);
    graphics.setColour(panelColour);
    graphics.fillRoundedRectangle(bounds, 10.0f);

    graphics.saveState();
    graphics.reduceClipRegion(plotArea.toNearestInt());

    graphics.setColour(gridColour);
    for (int i = 0; i <= StepBloomAudioProcessor::stepCount; ++i)
    {
        const auto x = plotArea.getX() + plotArea.getWidth()
            * static_cast<float>(i) / static_cast<float>(StepBloomAudioProcessor::stepCount);
        graphics.drawVerticalLine(static_cast<int>(x), plotArea.getY(), plotArea.getBottom());
    }
    for (int i = 0; i <= 4; ++i)
    {
        const auto y = plotArea.getY() + plotArea.getHeight() * static_cast<float>(i) / 4.0f;
        graphics.drawHorizontalLine(static_cast<int>(y), plotArea.getX(), plotArea.getRight());
    }

    juce::Path fill;
    juce::Path curve;
    std::array<float, StepBloomAudioProcessor::stepCount> values{};
    for (int i = 0; i < StepBloomAudioProcessor::stepCount; ++i)
    {
        const auto* parameter = parameters.getRawParameterValue("step" + juce::String(i));
        values[static_cast<size_t>(i)] = parameter != nullptr ? parameter->load() : 1.0f;
    }

    const auto seamValue = 0.5f
        * (values.back() + values.front());
    const auto seamY = plotArea.getBottom() - seamValue * plotArea.getHeight();
    curve.startNewSubPath(plotArea.getX(), seamY);
    fill.startNewSubPath(plotArea.getX(), plotArea.getBottom());
    fill.lineTo(plotArea.getX(), seamY);
    for (int i = 0; i < StepBloomAudioProcessor::stepCount; ++i)
    {
        const auto value = values[static_cast<size_t>(i)];
        const auto point = juce::Point<float>{
            plotArea.getX() + plotArea.getWidth()
                * (static_cast<float>(i) + 0.5f)
                / static_cast<float>(StepBloomAudioProcessor::stepCount),
            plotArea.getBottom() - value * plotArea.getHeight()
        };
        curve.lineTo(point);
        fill.lineTo(point);
    }

    curve.lineTo(plotArea.getRight(), seamY);
    fill.lineTo(plotArea.getRight(), seamY);
    fill.lineTo(plotArea.getRight(), plotArea.getBottom());
    fill.closeSubPath();
    graphics.setColour(accentColour.withAlpha(0.12f));
    graphics.fillPath(fill);
    graphics.setColour(accentColour);
    graphics.strokePath(curve, juce::PathStrokeType(2.0f));

    for (int i = 0; i < StepBloomAudioProcessor::stepCount; ++i)
    {
        const auto value = values[static_cast<size_t>(i)];
        const auto x = plotArea.getX() + plotArea.getWidth()
            * (static_cast<float>(i) + 0.5f)
            / static_cast<float>(StepBloomAudioProcessor::stepCount);
        const auto y = plotArea.getBottom() - value * plotArea.getHeight();
        graphics.setColour(accentColour);
        graphics.fillEllipse(x - 3.0f, y - 3.0f, 6.0f, 6.0f);
    }

    graphics.restoreState();
}

void StepBloomAudioProcessorEditor::CurveEditor::mouseDown(const juce::MouseEvent& event)
{
    const auto index = stepAtX(event.position.x);
    activeParameter = "step" + juce::String(index);
    if (auto* parameter = parameters.getParameter(activeParameter))
        parameter->beginChangeGesture();
    setStepFromPosition(event);
}

void StepBloomAudioProcessorEditor::CurveEditor::mouseDrag(const juce::MouseEvent& event)
{
    setStepFromPosition(event);
}

void StepBloomAudioProcessorEditor::CurveEditor::mouseUp(const juce::MouseEvent&)
{
    endGesture();
}

int StepBloomAudioProcessorEditor::CurveEditor::stepAtX(float x) const
{
    if (plotArea.getWidth() <= 0.0f)
        return 0;

    const auto position = (x - plotArea.getX()) / plotArea.getWidth();
    return juce::jlimit(0, StepBloomAudioProcessor::stepCount - 1,
        static_cast<int>(position * static_cast<float>(StepBloomAudioProcessor::stepCount)));
}

float StepBloomAudioProcessorEditor::CurveEditor::valueAtY(float y) const
{
    if (plotArea.getHeight() <= 0.0f)
        return 1.0f;

    return juce::jlimit(0.0f, 1.0f, (plotArea.getBottom() - y) / plotArea.getHeight());
}

void StepBloomAudioProcessorEditor::CurveEditor::setStepFromPosition(
    const juce::MouseEvent& event)
{
    if (activeParameter.isEmpty())
        return;

    if (auto* parameter = parameters.getParameter(activeParameter))
    {
        const auto value = juce::jlimit(0.0f, 1.0f, valueAtY(event.position.y));
        parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
    }

    repaint();
}

void StepBloomAudioProcessorEditor::CurveEditor::endGesture()
{
    if (activeParameter.isNotEmpty())
    {
        if (auto* parameter = parameters.getParameter(activeParameter))
            parameter->endChangeGesture();
        activeParameter.clear();
    }
}

StepBloomAudioProcessorEditor::StepBloomAudioProcessorEditor(
    StepBloomAudioProcessor& audioProcessor)
    : AudioProcessorEditor(&audioProcessor),
      processor(audioProcessor),
      curveEditor(audioProcessor.parameters)
{
    setSize(520, 360);

    depthLabel.setText("DEPTH", juce::dontSendNotification);
    depthLabel.setColour(juce::Label::textColourId, textColour);
    depthLabel.setFont(juce::FontOptions(12.0f, juce::Font::bold));
    addAndMakeVisible(depthLabel);

    depthSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    depthSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 64, 24);
    depthSlider.setTextValueSuffix("%");
    depthSlider.setColour(juce::Slider::trackColourId, accentColour);
    depthSlider.setColour(juce::Slider::thumbColourId, textColour);
    depthSlider.setColour(juce::Slider::textBoxTextColourId, textColour);
    depthSlider.setColour(juce::Slider::textBoxOutlineColourId, gridColour);
    addAndMakeVisible(depthSlider);
    depthAttachment = std::make_unique<StepBloomAudioProcessor::Parameters::SliderAttachment>(
        processor.parameters, "depth", depthSlider);

    cycleLabel.setText("CYCLE", juce::dontSendNotification);
    cycleLabel.setColour(juce::Label::textColourId, textColour);
    cycleLabel.setFont(juce::FontOptions(12.0f, juce::Font::bold));
    addAndMakeVisible(cycleLabel);

    cycleBox.addItemList(juce::StringArray{"1 bar", "2 bars", "4 bars"}, 1);
    cycleBox.setColour(juce::ComboBox::backgroundColourId, panelColour);
    cycleBox.setColour(juce::ComboBox::textColourId, textColour);
    cycleBox.setColour(juce::ComboBox::outlineColourId, gridColour);
    addAndMakeVisible(cycleBox);
    cycleAttachment = std::make_unique<StepBloomAudioProcessor::Parameters::ComboBoxAttachment>(
        processor.parameters, "cycle", cycleBox);

    addAndMakeVisible(curveEditor);
}

StepBloomAudioProcessorEditor::~StepBloomAudioProcessorEditor() = default;

void StepBloomAudioProcessorEditor::paint(juce::Graphics& graphics)
{
    graphics.fillAll(backgroundColour);
    graphics.setColour(textColour);
    graphics.setFont(juce::FontOptions(21.0f, juce::Font::bold));
    graphics.drawText("STEPBLOOM", 24, 18, 220, 30, juce::Justification::centredLeft);
    graphics.setColour(accentColour);
    graphics.setFont(juce::FontOptions(11.0f));
    graphics.drawText("VOLUME SHAPER", 25, 47, 200, 18, juce::Justification::centredLeft);
}

void StepBloomAudioProcessorEditor::resized()
{
    auto bounds = getLocalBounds().reduced(24);
    bounds.removeFromTop(72);

    auto controls = bounds.removeFromTop(42);
    depthLabel.setBounds(controls.removeFromLeft(56));
    depthSlider.setBounds(controls.removeFromLeft(220));
    controls.removeFromLeft(18);
    cycleLabel.setBounds(controls.removeFromLeft(50));
    cycleBox.setBounds(controls.removeFromLeft(110).reduced(0, 5));

    bounds.removeFromTop(14);
    curveEditor.setBounds(bounds);
}
