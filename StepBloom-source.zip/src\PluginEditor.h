#pragma once

#include "PluginProcessor.h"

class StepBloomAudioProcessorEditor final : public juce::AudioProcessorEditor
{
public:
    explicit StepBloomAudioProcessorEditor(StepBloomAudioProcessor&);
    ~StepBloomAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    class CurveEditor final : public juce::Component
    {
    public:
        explicit CurveEditor(StepBloomAudioProcessor::Parameters&);
        void paint(juce::Graphics&) override;
        void mouseDown(const juce::MouseEvent&) override;
        void mouseDrag(const juce::MouseEvent&) override;
        void mouseUp(const juce::MouseEvent&) override;

    private:
        int stepAtX(float x) const;
        float valueAtY(float y) const;
        void setStepFromPosition(const juce::MouseEvent&);
        void endGesture();

        StepBloomAudioProcessor::Parameters& parameters;
        juce::Rectangle<float> plotArea;
        juce::String activeParameter;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CurveEditor)
    };

    StepBloomAudioProcessor& processor;
    CurveEditor curveEditor;
    juce::Slider depthSlider;
    juce::ComboBox cycleBox;
    juce::Label depthLabel;
    juce::Label cycleLabel;
    std::unique_ptr<StepBloomAudioProcessor::Parameters::SliderAttachment> depthAttachment;
    std::unique_ptr<StepBloomAudioProcessor::Parameters::ComboBoxAttachment> cycleAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StepBloomAudioProcessorEditor)
};
