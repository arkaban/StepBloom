#include "PluginProcessor.h"
#include "PluginEditor.h"

#include <array>
#include <cmath>

namespace
{
constexpr std::array<float, StepBloomAudioProcessor::stepCount> defaultCurve{
    1.0f, 0.62f, 0.30f, 0.16f, 0.20f, 0.38f, 0.64f, 0.86f,
    1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f
};

constexpr double minimumBpm = 20.0;
constexpr double maximumBpm = 300.0;
}

juce::String StepBloomAudioProcessor::stepParameterId(int index)
{
    return "step" + juce::String(index);
}

StepBloomAudioProcessor::Parameters::ParameterLayout StepBloomAudioProcessor::createParameterLayout()
{
    Parameters::ParameterLayout layout;
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"depth", 1}, "Depth", juce::NormalisableRange<float>{0.0f, 100.0f},
        100.0f, juce::AudioParameterFloatAttributes{}.withLabel("%")));
    layout.add(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"cycle", 1}, "Cycle",
        juce::StringArray{"1 bar", "2 bars", "4 bars"}, 0));

    for (int i = 0; i < stepCount; ++i)
    {
        layout.add(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{stepParameterId(i), 1},
            "Step " + juce::String(i + 1),
            juce::NormalisableRange<float>{0.0f, 1.0f},
            defaultCurve[static_cast<size_t>(i)]));
    }

    return layout;
}

StepBloomAudioProcessor::StepBloomAudioProcessor()
    : AudioProcessor(BusesProperties()
                         .withInput("Input", juce::AudioChannelSet::stereo(), true)
                         .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

void StepBloomAudioProcessor::prepareToPlay(double sampleRate, int)
{
    fallbackPpq = 0.0;
    smoothedGain = 1.0;
    smoothingCoefficient = std::exp(-1.0 / (0.003 * sampleRate));
    depthParameter = parameters.getRawParameterValue("depth");
    cycleParameter = parameters.getRawParameterValue("cycle");
    for (int i = 0; i < stepCount; ++i)
        stepParameters[static_cast<size_t>(i)] =
            parameters.getRawParameterValue(stepParameterId(i));
}

void StepBloomAudioProcessor::releaseResources()
{
}

bool StepBloomAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto input = layouts.getMainInputChannelSet();
    const auto output = layouts.getMainOutputChannelSet();
    return input == output
        && (output == juce::AudioChannelSet::mono()
            || output == juce::AudioChannelSet::stereo());
}

void StepBloomAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                           juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const auto numSamples = buffer.getNumSamples();
    const auto numChannels = getTotalNumOutputChannels();

    for (int channel = getTotalNumInputChannels(); channel < numChannels; ++channel)
        buffer.clear(channel, 0, numSamples);

    if (numSamples == 0)
        return;

    const auto depth = (depthParameter != nullptr ? depthParameter->load() : 100.0f) * 0.01f;
    const auto cycleChoice = cycleParameter != nullptr
        ? static_cast<int>(cycleParameter->load())
        : 0;
    const auto cycleBeats = 4.0 * static_cast<double>(1 << juce::jlimit(0, 2, cycleChoice));

    std::array<float, stepCount> curve{};
    for (int i = 0; i < stepCount; ++i)
    {
        const auto* stepParameter = stepParameters[static_cast<size_t>(i)];
        curve[static_cast<size_t>(i)] = stepParameter != nullptr
            ? stepParameter->load()
            : defaultCurve[static_cast<size_t>(i)];
    }

    auto bpm = 120.0;
    auto ppqPosition = 0.0;
    auto useHostPosition = false;
    if (auto* playHead = getPlayHead())
    {
        if (const auto position = playHead->getPosition())
        {
            if (const auto hostBpm = position->getBpm())
                bpm = juce::jlimit(minimumBpm, maximumBpm, *hostBpm);

            if (position->getIsPlaying().value_or(false))
            {
                if (const auto ppq = position->getPpqPosition())
                {
                    ppqPosition = *ppq;
                    useHostPosition = true;
                }
            }
        }
    }

    const auto beatsPerSample = bpm / (60.0 * getSampleRate());

    for (int sample = 0; sample < numSamples; ++sample)
    {
        const auto ppq = useHostPosition
            ? ppqPosition + static_cast<double>(sample) * beatsPerSample
            : fallbackPpq;
        auto phase = std::fmod(ppq / cycleBeats, 1.0);
        if (phase < 0.0)
            phase += 1.0;

        const auto stepPosition = phase * static_cast<double>(stepCount) - 0.5;
        const auto lowerStep = static_cast<int>(std::floor(stepPosition));
        const auto stepIndex = (lowerStep % stepCount + stepCount) % stepCount;
        const auto nextIndex = (stepIndex + 1) % stepCount;
        const auto fraction = static_cast<float>(stepPosition - static_cast<double>(lowerStep));
        const auto envelope = curve[static_cast<size_t>(stepIndex)]
            + fraction * (curve[static_cast<size_t>(nextIndex)]
                          - curve[static_cast<size_t>(stepIndex)]);
        const auto targetGain = 1.0f - depth + depth * envelope;
        smoothedGain = smoothingCoefficient * smoothedGain
            + (1.0 - smoothingCoefficient) * static_cast<double>(targetGain);

        for (int channel = 0; channel < numChannels; ++channel)
            buffer.getWritePointer(channel)[sample] *= static_cast<float>(smoothedGain);

        if (!useHostPosition)
        {
            fallbackPpq += beatsPerSample;
            if (fallbackPpq >= cycleBeats)
                fallbackPpq = std::fmod(fallbackPpq, cycleBeats);
        }
    }
}

juce::AudioProcessorEditor* StepBloomAudioProcessor::createEditor()
{
    return new StepBloomAudioProcessorEditor(*this);
}

bool StepBloomAudioProcessor::hasEditor() const { return true; }
const juce::String StepBloomAudioProcessor::getName() const { return JucePlugin_Name; }
bool StepBloomAudioProcessor::acceptsMidi() const { return false; }
bool StepBloomAudioProcessor::producesMidi() const { return false; }
bool StepBloomAudioProcessor::isMidiEffect() const { return false; }
double StepBloomAudioProcessor::getTailLengthSeconds() const { return 0.0; }
int StepBloomAudioProcessor::getNumPrograms() { return 1; }
int StepBloomAudioProcessor::getCurrentProgram() { return 0; }
void StepBloomAudioProcessor::setCurrentProgram(int) {}
const juce::String StepBloomAudioProcessor::getProgramName(int) { return {}; }
void StepBloomAudioProcessor::changeProgramName(int, const juce::String&) {}

void StepBloomAudioProcessor::getStateInformation(juce::MemoryBlock& destinationData)
{
    const auto state = parameters.copyState();
    if (const auto xml = state.createXml())
        copyXmlToBinary(*xml, destinationData);
}

void StepBloomAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (const auto xml = getXmlFromBinary(data, sizeInBytes))
    {
        if (xml->hasTagName(parameters.state.getType()))
            parameters.replaceState(juce::ValueTree::fromXml(*xml));
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new StepBloomAudioProcessor();
}
