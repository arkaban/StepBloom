#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include <array>
#include <atomic>

class StepBloomAudioProcessor final : public juce::AudioProcessor
{
public:
    static constexpr int stepCount = 16;
    using Parameters = juce::AudioProcessorValueTreeState;

    StepBloomAudioProcessor();

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;
    const juce::String getName() const override;
    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int) override;
    const juce::String getProgramName(int) override;
    void changeProgramName(int, const juce::String&) override;
    void getStateInformation(juce::MemoryBlock& destinationData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    Parameters parameters;

private:
    static Parameters::ParameterLayout createParameterLayout();
    static juce::String stepParameterId(int index);

    double fallbackPpq = 0.0;
    double smoothedGain = 1.0;
    double smoothingCoefficient = 0.0;
    std::atomic<float>* depthParameter = nullptr;
    std::atomic<float>* cycleParameter = nullptr;
    std::array<std::atomic<float>*, stepCount> stepParameters{};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StepBloomAudioProcessor)
};
